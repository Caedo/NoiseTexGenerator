var searchData=
[
  ['width',['width',['../struct_noise_generator_w_p_f_1_1_noise_data.html#a21a53fd123d3a5154c908178556b5b62',1,'NoiseGeneratorWPF.NoiseData.width()'],['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a94aa3a046b7139fdf36c9f7f0eecae1c',1,'NoiseGeneratorWPF.ViewModel.MainWindowVM.Width()']]]
];
