var searchData=
[
  ['propertychanged',['PropertyChanged',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a7f0d5889316a2322f2f3c66c808b23d0',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
