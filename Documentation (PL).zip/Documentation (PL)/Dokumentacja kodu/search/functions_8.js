var searchData=
[
  ['relaycommand',['RelayCommand',['../class_noise_generator_w_p_f_1_1_relay_command.html#a5027bbd712ac327e6b35167e89beb99b',1,'NoiseGeneratorWPF.RelayCommand.RelayCommand(Action execute)'],['../class_noise_generator_w_p_f_1_1_relay_command.html#a3d2accf8fdafe682691d5129befaf23e',1,'NoiseGeneratorWPF.RelayCommand.RelayCommand(Action execute, Func&lt; bool &gt; canExecute)']]]
];
