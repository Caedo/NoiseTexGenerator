var searchData=
[
  ['savecommand',['SaveCommand',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a8c6c9695f209813f02d8859be9379950',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]],
  ['scale',['Scale',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#ad08a2789216932917edf398a96d57e45',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]],
  ['selectednoisetype',['SelectedNoiseType',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#ab565e454b6cadd86d96be732a2112415',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
