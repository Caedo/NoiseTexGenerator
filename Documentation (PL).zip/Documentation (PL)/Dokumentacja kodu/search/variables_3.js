var searchData=
[
  ['persistance',['persistance',['../struct_noise_generator_w_p_f_1_1_noise_data.html#aee35e8cf350d550e74091c2627eab962',1,'NoiseGeneratorWPF::NoiseData']]]
];
