var searchData=
[
  ['name',['Name',['../class_noise_generator_w_p_f_1_1_noise_attribute.html#a940c2ba321122e1714789fd3d0555213',1,'NoiseGeneratorWPF::NoiseAttribute']]],
  ['noisetypes',['NoiseTypes',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a3043f2a197d54c75cf673659b987b9bd',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
