var searchData=
[
  ['refreshcommand',['RefreshCommand',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a6240f2006081cc117b157d32ae9a8b4e',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
