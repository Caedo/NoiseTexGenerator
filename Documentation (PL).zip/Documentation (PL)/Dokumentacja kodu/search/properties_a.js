var searchData=
[
  ['turbulence',['Turbulence',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a2e440ef555b7cccfa3022c946d5294f5',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
