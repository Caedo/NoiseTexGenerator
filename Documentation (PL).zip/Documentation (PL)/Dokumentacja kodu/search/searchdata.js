var indexSectionsWithContent =
{
  0: "abcdeghilmnoprstvw",
  1: "abimnprsv",
  2: "n",
  3: "abimnprsv",
  4: "cdegilmnrs",
  5: "hlopstw",
  6: "abchlnoprstw",
  7: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties",
  7: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties",
  7: "Events"
};

