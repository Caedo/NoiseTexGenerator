var searchData=
[
  ['ibitmaprenderer',['IBitmapRenderer',['../interface_noise_generator_w_p_f_1_1_i_bitmap_renderer.html',1,'NoiseGeneratorWPF']]],
  ['inoise',['INoise',['../interface_noise_generator_w_p_f_1_1_i_noise.html',1,'NoiseGeneratorWPF']]]
];
