var searchData=
[
  ['mainwindow',['MainWindow',['../class_noise_generator_w_p_f_1_1_main_window.html#ac23da902b853e8fcc25bd5f69c291997',1,'NoiseGeneratorWPF::MainWindow']]],
  ['mainwindowvm',['MainWindowVM',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#ad70c9aaaf17fc6eecee878c209896f66',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
