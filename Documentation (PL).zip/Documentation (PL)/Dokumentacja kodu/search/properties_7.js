var searchData=
[
  ['persistance',['Persistance',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#ad00f244f4ab4c1be035bb124d64a82e1',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]]
];
