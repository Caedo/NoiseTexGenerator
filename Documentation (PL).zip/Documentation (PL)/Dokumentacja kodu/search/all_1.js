var searchData=
[
  ['bitmap',['Bitmap',['../class_noise_generator_w_p_f_1_1_view_model_1_1_main_window_v_m.html#a76495086a5649f6a13efc893705c0c90',1,'NoiseGeneratorWPF::ViewModel::MainWindowVM']]],
  ['bitmaprenderer',['BitmapRenderer',['../class_noise_generator_w_p_f_1_1_bitmap_renderer.html',1,'NoiseGeneratorWPF']]],
  ['bitmaprenderer_2ecs',['BitmapRenderer.cs',['../_bitmap_renderer_8cs.html',1,'']]]
];
