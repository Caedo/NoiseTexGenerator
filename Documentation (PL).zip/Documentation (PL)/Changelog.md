# NoiseTex ChangeLog

## [1 kwiecień 2018](https://github.com/Caedo/NoiseTexGenerator/compare/9002d613d8c7ef096d8eb57d63351126fd9f992e...master)
* Zaimplementowano Value Noise

## [28 kwiecień 2018](https://github.com/Caedo/NoiseTexGenerator/compare/9002d613d8c7ef096d8eb57d63351126fd9f992e...3f4763e42a976bc69eafbcc91f4c12a58b635d8f)
* Zmiana używanej technologii na WPF

## [29 kwietnia 2018](https://github.com/Caedo/NoiseTexGenerator/compare/3f4763e42a976bc69eafbcc91f4c12a58b635d8f...0861408c4c8159511fec10a9aa0f7c83a62312b3)
* Zaimplementowano szum Perlina
* Dodano normalizacje wartości szumów
* Dodano suwaki przesunięcia pozycji szumu
* Dodano przycisk "Save" - aktualnie wersja testowa

## [30 kwiecień 2018](https://github.com/Caedo/NoiseTexGenerator/compare/0861408c4c8159511fec10a9aa0f7c83a62312b3...2d30aa3f589553c67c35cbb9c1a40f4764a72565)
* Dodano opcję zapisu
* Zmieniono sposób skalowania obrazu

## [2 maj 2018](https://github.com/Caedo/NoiseTexGenerator/compare/2d30aa3f589553c67c35cbb9c1a40f4764a72565...9e0ec6789eb209d98de503705eefa59fec8603b4)
* Dodano efekt turbulencji
* Zmieniono wygląd interfejsu

## [4 maj 2018](https://github.com/Caedo/NoiseTexGenerator/compare/9e0ec6789eb209d98de503705eefa59fec8603b4...8daea08e2a0736d096130e7667157aa9c250c32b)
* Bitmapy są teraz tworzone na osobnym wątku

## [1 czerwiec 2018](https://github.com/Caedo/NoiseTexGenerator/compare/8daea08e2a0736d096130e7667157aa9c250c32b...94ef4874aedccef2e733e2374dae4e0724b05d44)
* Dodano snapping na suwakach
* Zmieniono funkcję Lerp na ardziej optymalną
* Zmieniono nazwę okna
* Naprawiono tearing na bitmapach

## [2 czerwca 2018](https://github.com/Caedo/NoiseTexGenerator/compare/94ef4874aedccef2e733e2374dae4e0724b05d44...e19c3604f988056fb7b257003e38017ef117061a)
* Wpisywane wartości są teraz ograniczane
* Ograniczono wielkość tekstury do 4096 pikseli